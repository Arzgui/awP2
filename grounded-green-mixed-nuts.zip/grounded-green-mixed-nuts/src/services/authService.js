import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = 'https://website-checker.boreales-creations.fr';

export const login = async (email, password) => {
  try {
    const response = await fetch(`${API_URL}/auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/ld+json',
      },
      body: JSON.stringify({ email, password }),
    });

    const data = await response.json();
    console.log(data);

    if (data.token) {
      await AsyncStorage.setItem('token', data.token);
      return data;
    } else {
      throw new Error('Token not found in response');
    }
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
};

export const getToken = async () => {
  return await AsyncStorage.getItem('token');
};

export const logout = async () => {
  await AsyncStorage.removeItem('token');
};
