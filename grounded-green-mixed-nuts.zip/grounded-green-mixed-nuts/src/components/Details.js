import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const Details = ({ route }) => {
  const { item } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Details Screen</Text>
      <Text style={styles.itemText}>Détails de l'élément : {item}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  itemText: {
    fontSize: 18,
  },
});

export default Details;
