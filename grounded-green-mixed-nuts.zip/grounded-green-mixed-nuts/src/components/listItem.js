import React from 'react';
import { View, FlatList, StyleSheet, Text, Image, Button } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const FlatListSites = () => {
  const data = [
    { id: 1, title: 'Customer Site 1' },
    { id: 2, title: 'Customer Site 2' },
    { id: 3, title: 'Customer Site 3' },
    
  ];

  const navigation = useNavigation();

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.item}
      onPress={() => navigation.navigate('Details', { id: item.id })}
    >
      <Text style={styles.title}>{item.title}</Text>
    </TouchableOpacity>
  );

  return (
    <View>
      <FlatList
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
        style={styles.listContainer}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  listContainer: {
   
  },
  item: {
    width: 300,
    padding: 10,
    marginVertical: 10,
    marginHorizontal: 16,
    borderWidth: 2,
    borderColor: 'red',
    borderRadius: 10,
    fontSize: 32,
  },
  title: {
    
  },
});

export default FlatListSites;
