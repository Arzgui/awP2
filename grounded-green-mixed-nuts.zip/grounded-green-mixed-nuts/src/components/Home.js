import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  FlatList,
  TouchableHighlight,
  Button,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ListHeader from './websitecheckHeader';
import ListFooter from './websitecheckFooter';
import AddItemButton from './AddItemButton';
import HomeButton from './HomeButton';
import { logout } from '../services/authService';

const Home = ({ navigation }) => {
  const isDarkMode = useColorScheme() === 'dark';
  const [items, setItems] = useState([]);
  const [newItem, setNewItem] = useState('');

  const handleAddItem = async () => {
    if (newItem) {
      const updatedItems = [...items, newItem];
      setItems(updatedItems);
      setNewItem('');
      await AsyncStorage.setItem('@items', JSON.stringify(updatedItems));
    }
  };

  const loadData = async () => {
    try {
      const storedItems = await AsyncStorage.getItem('@items');
      if (storedItems !== null) {
        setItems(JSON.parse(storedItems));
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    const storeData = async (value) => {
      try {
        await AsyncStorage.setItem('@items', JSON.stringify(value));
      } catch (error) {
        console.error('Error saving data:', error);
      }
    };
    storeData(items);
  }, [items]);

  const handleDeleteItem = async (index) => {
    const newListItems = items.filter((_, i) => i !== index);
    setItems(newListItems);
    try {
      await AsyncStorage.setItem('@items', JSON.stringify(newListItems));
    } catch (error) {
      console.error('Failed to delete item from AsyncStorage', error);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      Alert.alert('Logout Successful');
      navigation.replace('Login');
    } catch (error) {
      Alert.alert('Logout Failed', error.message);
    }
  };

  const backgroundStyle = {
    backgroundColor: isDarkMode ? '#333' : '#FFF', // Change this to the desired colors
  };

  const renderItem = ({ item, index }) => (
    <SafeAreaView>
      <View style={styles.itemContainer}>
        <Text>{item}</Text>
        <HomeButton item={item} />
        <TouchableHighlight onPress={() => handleDeleteItem(index)}>
          <Text style={styles.deleteButton}>Delete</Text>
        </TouchableHighlight>
      </View>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={backgroundStyle}>
      <ListHeader />
      <ScrollView contentInsetAdjustmentBehavior="automatic" style={backgroundStyle}>
        <View style={styles.headerButtons} />
        <View style={styles.container}>
          <AddItemButton newItem={newItem} setNewItem={setNewItem} handleAddItem={handleAddItem} />
        </View>
      </ScrollView>
      <ListFooter />
      <FlatList data={items} renderItem={renderItem} keyExtractor={(item, index) => index.toString()} />
      <View style={styles.logoutButtonContainer}>
        <Button title="Logout" onPress={handleLogout} />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  itemContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    borderBottomWidth: 1,
    borderColor: '#ccc',
  },
  deleteButton: {
    color: '#A45D9E',
  },
  headerButtons: {},
  logoutButtonContainer: {
    position: 'absolute',
    bottom: 20,
    right: 20,
  },
});

export default Home;
