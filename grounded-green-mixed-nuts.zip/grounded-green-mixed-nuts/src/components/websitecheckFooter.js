import React from 'react';
import { View, Text } from 'react-native';

const ListFooter = () => {
  return (
    <View>
        <Text style={{color:'black', fontWeight: "bold", fontSize: 22, backgroundColor:"black"}}>Sites Stalking Company®           Rmag</Text>
    </View>
  );
};

export default ListFooter;