import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './src/components/Home';
import Details from './src/components/Details';
import Login from './src/components/login';
import { getToken, logout } from './src/services/authService';
import { Alert, Button, StyleSheet, View } from 'react-native';

const Stack = createNativeStackNavigator();

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      const token = await getToken();
      if (token) {
        setIsAuthenticated(true);
      }
      setLoading(false);
    };
    checkAuth();
  }, []);

  const handleLogout = async (navigation) => {
    try {
      await logout();
      Alert.alert('Logout Successful');
      setIsAuthenticated(false);
      navigation.replace('Login');
    } catch (error) {
      Alert.alert('Logout Failed', error.message);
    }
  };

  if (loading) {
    return null; 
  }

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName={isAuthenticated ? "Home" : "Login"}>
        {isAuthenticated ? (
          <>
            <Stack.Screen name="Home">
              {(props) => <Home {...props} onLogout={() => handleLogout(props.navigation)} />}
            </Stack.Screen>
            <Stack.Screen name="Details" component={Details} />
          </>
        ) : (
          <Stack.Screen name="Login">
            {(props) => <Login {...props} onLoginSuccess={() => setIsAuthenticated(true)} />}
          </Stack.Screen>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  logoutButtonContainer: {
    position: 'absolute',
    bottom: 20,
    right: 20,
  },
});

export default App;
